<g>
  <path
    d="M149.995 149.995L50.9999 51"
    stroke-width="20"
    stroke-linecap="round"
  />
  <path d="M51 149.995L149.995 51" stroke-width="20" stroke-linecap="round" />
</g>

<style>
  g {
    transform-origin: center;
  }
  :global(*:hover > svg) > g {
    transform: scale(1.2);
  }
  :global(*:active > svg) > g {
    transform: scale(1);
  }
</style>
