export let citeLabels = {
  tag: 'Tag',
  title: 'Title',
  siteName: 'Site Name',
  url: 'URL',
  accessDate: 'Access Date',
  date: 'Date',
  authors: 'Authors',
};
